# Authy Puppet Module for Boxen
[![Build Status](https://travis-ci.org/boxen/puppet-authy.svg?branch=master)](https://travis-ci.org/boxen/puppet-authy)

Installs [Authy Bluetooth Pairing](https://www.authy.com/thefuture) app

## Usage

```puppet
include authy
```

## Required Puppet Modules

* boxen
* stdlib
