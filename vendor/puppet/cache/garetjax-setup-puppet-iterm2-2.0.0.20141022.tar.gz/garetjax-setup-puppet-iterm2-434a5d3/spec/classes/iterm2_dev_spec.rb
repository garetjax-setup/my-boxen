require 'spec_helper'

describe 'iterm2::dev' do
  it do
    version = '20141022'
    should contain_package("iTerm").with({
      :source   => "http://www.iterm2.com/downloads/beta/iTerm2-2_0_0_#{version}.zip",
      :provider => 'compressed_app'
    })
  end
end
